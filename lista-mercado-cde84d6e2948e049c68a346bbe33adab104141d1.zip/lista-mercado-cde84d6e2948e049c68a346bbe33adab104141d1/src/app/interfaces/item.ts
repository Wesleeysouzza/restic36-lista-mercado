export interface Item {
    id: number;
    nome: string;
    comprado: boolean;
  }
  